/**
 * Tab Flash — content script
 * Shows an animated checkmark to the right of the cursor on Cmd/Ctrl+click.
 */

const ANIM_CLEANUP_MS = 1000;

function flash(x, y) {
  const wrap = document.createElement('div');
  wrap.className = 'tab-flash-wrap';
  wrap.style.left = `${x}px`;
  wrap.style.top  = `${y}px`;

  wrap.innerHTML = `
    <div class="tab-flash-pill">
      <svg class="tab-flash-svg" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">
        <polyline class="tab-flash-check" points="2,7 5.5,11 12,3"/>
      </svg>
    </div>
  `;

  document.documentElement.appendChild(wrap);
  setTimeout(() => wrap.remove(), ANIM_CLEANUP_MS);
}

document.addEventListener('click', (e) => {
  const isNewTabClick = e.metaKey || e.ctrlKey;
  if (!isNewTabClick) return;

  const link = e.target.closest('a[href]');
  if (!link) return;

  const href = link.getAttribute('href');
  if (!href || href.startsWith('javascript:')) return;

  flash(e.clientX, e.clientY);
}, true);
